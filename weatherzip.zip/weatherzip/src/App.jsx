import Weather from "./components/Weather"
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {


  return (
    <>
     <Weather/>
    </>
  )
}

export default App
