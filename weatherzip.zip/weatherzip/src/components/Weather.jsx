import React, { useState } from 'react';
import { Container, Form, Row, Col, Card, Button } from 'react-bootstrap';
import axios from 'axios';

const Weather = () => {
  const [city, setCity] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const apiKey = 'f66d9727501911f62c328508b94c5e3e';

  const fetchWeather = async () => {
    try {
      const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`);
      setWeatherData(response.data);
    } catch (error) {
      console.log("Weather Error Occurred", error);
    }
  };

  const fetchForecast = async () => {
    try {
      const response = await axios.get(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}`);
      setForecastData(response.data.list);
    } catch (error) {
      console.log("Forecast Error Occurred", error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWeather();
    fetchForecast();
    setCity("");
  };

  const kelvinToCelsius = (kelvin) => (kelvin - 273.15).toFixed(2);

  const getForecastForNextFiveDays = (data) => {
    const filteredData = data.filter(forecast => {
      return forecast.dt_txt.includes("09:00:00");
    }).slice(0, 5);

    return filteredData;
  };

  const forecastForNextFiveDays = forecastData ? getForecastForNextFiveDays(forecastData) : [];

  return (
    <div>
      <Container className="mt-5">
        <Form onSubmit={handleSubmit}>
          <Row className="mb-4">
            <Col md={10}>
              <Form.Control
                type="text"
                placeholder="Search for a city..."
                value={city}
                onChange={(e) => setCity(e.target.value)}
                style={{ borderRadius: '25px', borderColor: '#ff6347' }}
              />
            </Col>
            <Col md={2}>
              <Button variant="primary" type="submit" className="btn-block" style={{ backgroundColor: '#ff6347', borderColor: '#ff6347' }}>
                Search
              </Button>
            </Col>
          </Row>
        </Form>
        {weatherData && (
          <div className="mt-4">
            <h3 className="text-primary" style={{ color: '#4682b4' }}>{weatherData.name}</h3>
            <Row>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#ffebcd', border: '1px solid #deb887' }}>
                  <Card.Body>
                    <Card.Title>Description</Card.Title>
                    <Card.Text>{weatherData.weather[0].description}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#ffdaff', border: '1px solid #d3a8b5' }}>
                  <Card.Body>
                    <Card.Title>Temperature</Card.Title>
                    <Card.Text>{`Temperature: ${kelvinToCelsius(weatherData.main.temp)}°C`}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#b0e57c', border: '1px solid #8fbc8f' }}>
                  <Card.Body>
                    <Card.Title>Max Temperature</Card.Title>
                    <Card.Text>{`Temperature: ${kelvinToCelsius(weatherData.main.temp_max)}°C`}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#ffb6c1', border: '1px solid #ff69b4' }}>
                  <Card.Body>
                    <Card.Title>Min Temperature</Card.Title>
                    <Card.Text>{`Temperature: ${kelvinToCelsius(weatherData.main.temp_min)}°C`}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#add8e6', border: '1px solid #87cefa' }}>
                  <Card.Body>
                    <Card.Title>Humidity</Card.Title>
                    <Card.Text>{weatherData.main.humidity}%</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#d3ffd3', border: '1px solid #aaf0d1' }}>
                  <Card.Body>
                    <Card.Title>Pressure</Card.Title>
                    <Card.Text>{weatherData.main.pressure} hPa</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#e6e6fa', border: '1px solid #d0d0ff' }}>
                  <Card.Body>
                    <Card.Title>Sunrise</Card.Title>
                    <Card.Text>{new Date(weatherData.sys.sunrise * 1000).toLocaleTimeString()}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#f5f5dc', border: '1px solid #dcdcdc' }}>
                  <Card.Body>
                    <Card.Title>Sunset</Card.Title>
                    <Card.Text>{new Date(weatherData.sys.sunset * 1000).toLocaleTimeString()}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={4} className="mb-4">
                <Card className="text-center" style={{ backgroundColor: '#f0e68c', border: '1px solid #dada40' }}>
                  <Card.Body>
                    <Card.Title>Country</Card.Title>
                    <Card.Text>{weatherData.sys.country}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </div>
        )}
        {forecastForNextFiveDays.length > 0 && (
          <div className="mt-4">
            <h3 className="text-success" style={{ color: '#32cd32' }}>5-Day Weather Forecast</h3>
            <Row>
              {forecastForNextFiveDays.map((forecast, index) => (
                <Col md={4} className="mb-4" key={index}>
                  <Card className="text-center" style={{ backgroundColor: '#d3ffd3', border: '1px solid #aaffaa' }}>
                    <Card.Body>
                      <Card.Title>{new Date(forecast.dt_txt).toLocaleDateString()}</Card.Title>
                      <Card.Text>{`Temperature: ${kelvinToCelsius(forecast.main.temp)}°C`}</Card.Text>
                      <Card.Text>{`Weather: ${forecast.weather[0].description}`}</Card.Text>
                      <Card.Text>{`Wind Speed: ${forecast.wind.speed} m/s`}</Card.Text>
                      <Card.Text>{`Humidity: ${forecast.main.humidity}%`}</Card.Text>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          </div>
        )}
      </Container>
    </div>
  );
};

export default Weather;
